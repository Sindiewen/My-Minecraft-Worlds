This zip contains my Minecraft world with its subway system.  The subway has a main station and runs 1,369 track sections to the nearest beach.  The mainenance area where the subway parts are laid out could be a lot more compact but I chose to make it huge because I had space available and plan to add things in the future.

Installation instructions:
1. Open up "My Computer"
2. Type the following into the address bar at the top, including the percent signs: %appdata%\.minecraft\saves
3. Temporarily rename the World4 folder to something else like "World4Backup"
4. Extract the zip file that contains my world.
5. Play!