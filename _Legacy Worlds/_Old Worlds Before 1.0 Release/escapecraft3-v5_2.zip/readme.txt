EscapeCraft 3


Installation:

1. Unzip the EscapeCraft 3 alpha file into your Minecraft save directory (For Windows Vista and later, this is found in "Username" -> AppData -> .minecraft -> saves)

2. Rename the "World_" folder to "World#" (# = 1 through 5) NOTE THIS WILL OVERWRITE PREVIOUS SAVED GAMES!!! BACKUP ANY WORLDS YOU DON'T WANT TO LOSE!!!!

3. Open Minecraft, and select Mods and Texture Packs, then click "Open Texture Pack Folder"

4. Place the "EC3 Texture Pack" file in the Texture Pack folder (DO NOT UNZIP!!!!)

5. Load World# (whatever # you renamed the EscapeCraft folder to).

6. Enjoy!!!



Legal Stuff

Since this is a TEST ONLY copy, please do not repost, link, or in any other way distribute this file without express permission of its creator.  This includes posting pictures or video of the game, leaving "hints" or any other information about EscapeCraft3 on the forums or elsewhere.